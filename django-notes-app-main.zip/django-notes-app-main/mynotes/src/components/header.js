const Header = () => {
    return (
        <div className="app-header">
            <h1>My Notes</h1>
        </div>
    )
}

export default Header